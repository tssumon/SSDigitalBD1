/**
 * DigiMarket Production Server Entry Point
 * Full-stack Express server with API routing and React SPA fallback.
 */

import express from 'express';
import path from 'path';
import fs from 'fs';
import { apiRouter } from './server/api/routes.ts';

const app = express();
const PORT = process.env.PORT || 3000;

// Production Trust Proxy (Hostinger / Reverse Proxy / Cloudflare)
app.set('trust proxy', 1);

// JSON and URL-encoded body parsers with 10MB limit for screenshot evidence
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// Health check endpoints for monitoring (Render / cPanel / Docker)
app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime(), timestamp: new Date().toISOString() });
});
app.get('/api/health', (_req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime(), timestamp: new Date().toISOString() });
});

// Mount API router
app.use('/api', apiRouter);

// Static uploads delivery for product images (using persistent DATA_DIR if configured)
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(process.cwd(), '.data');
const uploadsPath = path.join(DATA_DIR, 'uploads');
if (!fs.existsSync(uploadsPath)) {
  fs.mkdirSync(uploadsPath, { recursive: true });
}
app.use('/uploads', express.static(uploadsPath, { maxAge: '7d' }));

// Static frontend delivery
const distPath = path.resolve(process.cwd(), 'dist');
const indexPath = path.join(distPath, 'index.html');

// Serve built assets if dist directory exists
app.use(
  express.static(distPath, {
    maxAge: '1d',
    index: false,
  })
);

// Explicit direct routes for portal views ensuring direct URL access & refresh
app.get(
  ['/', '/admin', '/admin/*', '/customer', '/customer/*', '/seller', '/seller/*', '/reseller', '/reseller/*', '/store/*'],
  (_req, res) => {
    if (fs.existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }
    return res.status(200).send(
      'SSDigitalBD.shop Backend Initialized. Generating production client bundle...'
    );
  }
);

// SPA fallback: send index.html for any non-API routes
app.get('*', (req, res) => {
  if (req.path.startsWith('/api')) {
    return res.status(404).json({ error: 'API endpoint not found.' });
  }
  if (fs.existsSync(indexPath)) {
    return res.sendFile(indexPath);
  }
  return res.status(200).send(
    'SSDigitalBD.shop Backend Running. Run "npm run build" to generate client production bundle.'
  );
});

// Start HTTP server on 0.0.0.0 (when not imported by tests)
if (process.env.NODE_ENV !== 'test') {
  const server = app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`[SSDigitalBD.shop] Production server listening on 0.0.0.0:${PORT}`);
  });

  // Graceful termination handling
  process.on('SIGTERM', () => {
    console.log('[SSDigitalBD.shop] SIGTERM received. Shutting down gracefully...');
    server.close(() => {
      process.exit(0);
    });
  });
}

export default app;
